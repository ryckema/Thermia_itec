Thermia iTec XTR M — Passive Full RX-only (2026-11-17)
=======================================================
This package extends the exact GitHub Passive 1.0 baseline.
No transmit pin, no physical RS485 transmission, no DCM session,
no FC03 selector, no FC16 ACK. Receiver-only controller-origin pages.

Included:
 - Existing production sensor map, UART parser, CRC and bus health
 - Passive 085F/5 alarms: 29 source-backed named alarm flags
 - Passive 0884/60 history: 8 entries with guarded 6- or 7-word layout
 - Passive 0870/17: 8 OEM lifetime operating-hour counters
 - Passive 087B/087C/087D: defrost count/elapsed and guarded raw duration
 - Passive 0848: Heat Demand PID for verified CM930 2.4.2 profile
 - 0x1E FC04 compressor starts and run times since ESP boot
 - Missing/stale page diagnostics; no fake 'no alarms' on missing RX

Expected:
 - Existing normal passive temperatures/compressor/operating state remain
 - Optional 0x0F pages only populate when genuinely transmitted.
 - Without DCM, 0848/0870/0884 may never appear.
 - 085F zero words indicate no flags in THIS page, not OEM-wide all-clear.
 - History timestamp format is a guarded candidate; codes are raw.
 - Last defrost duration 087D may be anomalous: invalid >60/negative => NAN.
 - Compressor counts reset on ESP reboot; gap >30s prevents false cycles.

Install:
  1. Download/extract this ZIP.
  2. Use the YAML in ESPHome (same Waveshare ESP32-S3 board/pins as base).
  3. Keep your existing ESPHome secrets.yaml (not included).
  4. Compile and flash manually; do not enable any TX.
  5. Observe 'Diagnostic | Passive Optional Pages' and RX frame counters.
  6. Capture a short log only if a page/CRC or interpretation is inconsistent.

ABORT/rollback:
  No physical TX is possible in this YAML. If telemetry becomes unstable,
  restore the original Passive 1.0 YAML from the main branch and reflash:
  https://github.com/ryckema/Thermia_itec/blob/main/Thermia%20iTec%20XTR/thermia_itec_xtr_passive_1.0.yaml

Status: SOURCE / OFFLINE STATIC CHECKED; NOT TARGET COMPILED,
NOT FLASHED/LIVE or locally verified on this exact build.
Main branch, protected README and iTec Eco unchanged.
