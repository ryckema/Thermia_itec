THERMIA iTec XTR M — PASSIVE 1.1 Full RX-only
================================================
SOURCE: current main Passive 1.0, extended via Full RX branch with newer
OEM CM930 2.4.2 findings and public Write User 1.01 read-only semantics.

No DCM session, no TX pin, no FC03 read requests, no FC16 acknowledgements.
All pages are received only when a controller actually transmits them.

IMPROVEMENTS
  * Same UART owner with V5 longest-CRC-valid framing and RX integrity counters
  * Independent 0x1E, 0x02/FC17, 0x0A/FC17, 0x0F/FC16 source freshness
  * 0x1E compressor, fan, temperature and mode entities turn unknown on age >10s
  * 085F/5 active alarms: 29 known flags with OEM cross-bit conditions,
    plus any unknown flags; no false all-system alarm clear
  * 0884/60 history: one common timestamp-validated layout decision
    (10 x 6-word XTR / 8 x 7-word Eco); ten visible entries,
    plus three raw twenty-word blocks covering all 60 words
  * 0870/17: eight OEM operating-hour totals, defrost cycles and minutes
    since last defrost; last defrost duration unverified and hidden
  * 0848 heat-demand PID on the locally verified CM930 2.4.2 profile
  * 0x1E compressor starts, completed runs, last/mean run duration
    observed since ESP boot; observation gaps cannot fabricate cycles
  * Diagnostic for flash-restored heating/settings cache vs live 03E8 receipt
  * Existing production telemetry, HA entities and GPIO21 low RX preserved

LIMITS
  * RX-only cannot force any 0x0F page to appear. Even if 085F is offered
    autonomously, 0848/0870/0884 might remain MISSING without a DCM.
  * A received 085F five-word all-zero snapshot means only those flags clear.
  * Alarm history numeric event identifiers have no validated name mapping.
  * History layout remains AMBIGUOUS when timestamps give insufficient proof.
  * 087D last defrost duration semantics unverified; raw and guarded diagnostic.
  * Passive heating cache can be restored from prior boot without a fresh 03E8.
  * Compressor statistics reset at ESP reboot and exclude incomplete runs.

INSTALL / FLASH
  1. Use thermia_itec_xtr_passive_1.1.yaml in ESPHome.
  2. Keep existing secrets.yaml with wifi/api/ota keys. No secrets shipped.
  3. Target the same Waveshare ESP32-S3-RS485-CAN board as baseline:
     ESP32-S3 octal PSRAM, UART RX GPIO18, DE GPIO21 held LOW.
  4. Validate/compile using ESPHome, then flash manually via USB/OTA.
     No physical TX or write-experiment switch exists in this firmware.
  5. Check Diagnostic | Bus Source Freshness, Diagnostic | Passive Optional
     Pages, Diagnostic | Passive V5 RX Integrity and alarm/history entities.
  6. When source says MISSING, let it remain unknown: do not invent a value.

ABORT / ROLLBACK
  * If HA states or RX framing regress, reflash
    rollback/thermia_itec_xtr_passive_1.0.yaml
    (byte-identical original public main Passive 1.0).
  * There is nothing to ABORT on the bus: no UART TX, no requests or ACK.
  * For safe bench tests, keep the 3.3V-compatible RS485 transceiver,
    shared ground and isolated receiver as in verified hardware.

EVIDENCE
  SOURCE / OFFLINE STATIC CHECKED; NOT ESPHOME TARGET COMPILED,
  NOT FLASHED, NOT LIVE or LOCALLY VERIFIED for this build.
  Passive no-DCM availability of optional pages remains controller-dependent.
Main, README.md and Write (Beta)/iTec Eco were not modified.
