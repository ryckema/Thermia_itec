# Thermia iTec XTR M — Write User RC09FC-UI1 | Public Beta

This is the complete ESPHome YAML for local native DCM monitoring and manually controlled Home Assistant Write User operations on the **Thermia iTec XTR M 3N / CM930 2.4.2** profile. It is a beta, not a universal Thermia driver. It preserves the existing S92 single UART/RX/TX/DE owner, V5 CRC parser, FC16/FC03, hot-rejoin, bounded recovery, W2R97 alarm refresh and 32-slot calendar with previously verified weekly F1/F2/F3 writes.

## DCM startup and code distribution

The DCM FC23 startup is **exactly the same fixed 29-byte request / 21-byte recorded response** as the repository's already published `Thermia iTec XTR/thermia_itec_xtr_DCM_readonly_1.0.yaml`. Only that complete captured request matches. A different challenge fails closed; this is **not a general-purpose challenge/response algorithm**. There is **no XXTEA calculation**, firmware-derived cryptographic response, or additional handshake key schedule in this public source. Historical log wording suggesting otherwise was corrected without changing the response bytes or TX behavior.

## Setup

1. Use Waveshare ESP32-S3-RS485-CAN and the existing verified RS485 wiring; never connect the heat pump's 12 V supply to the RS485 terminals. Existing hardware wiring for DCM Read Only applies.
2. Copy `Thermia_iTec_XTR_M_WRITE_USER_RC09FC_UI1_PUBLIC_BETA.yaml` to your ESPHome device configuration (for an existing owner setup, keep the existing filename). Keep `secrets.yaml` private; required names are `wifi_ssid`, `wifi_password`, `thermia_api_encryption_key`, `thermia_ota_password`, `thermia_fallback_password`.
3. Compile in ESPHome and flash the Waveshare device. No additional CSV or local authorization file is needed.
4. Verify `Diagnostic | Firmware Build` shows `USER-RC09FC-UI1 PUBLIC BETA`, then native session `M6=5` and controller CURRENT `4/4` FC16 readback. Normal operating telemetry and calendar source refresh should continue.
5. When Write User is enabled by the existing controller/session preflight, use only supported Home Assistant parameter edits. Wait for authoritative controller FC16 readback. The UI1 fix prevents misleading intermediate same-field HA state bounce; it is **offline checked but not yet owner live-confirmed**.

## Important limits and rollback

- Calibration, service writes and unverified user parameters are **not** authorized by this beta.
- Fixed exact-capture DCM startup is not guaranteed on other firmware/controller challenges. Failure to match must not be bypassed.
- Prior validated calendar writes remain present. No re-test is required absent contradiction.
- `Configuration | ABORT Native Session` stops native TX; revert to `ROLLBACK/Thermia_iTec_XTR_M_WRITE_USER_RC09FC_PRE_UI1.yaml` and flash if new UI behavior regresses. Controller parameters that have already been accepted persist independently of a firmware rollback.
- `Configuration | Automatic Parameter Writes` remains OFF; user parameter edits are manual and subject to OEMW state/epoch checks and controller confirmation.

**Evidence:** RC09FC W2R92 controller runtime, CURRENT 4/4 twice, 085F/5 read and calendar refresh were observed LIVE 2026-11-09. RC09FC-UI1's HA presentation change has only been validated offline; it requires ESPHome target compilation and user flash before being called LIVE.
